package dev.amble.lib.datagen.lang;

public enum LanguageType {
    EN_US("en_us"),
    EN_UK("en_gb"), // Minecraft uses en_gb for UK English
    EN_GB("en_gb"),
    FR_CA("fr_ca"),
    FR_FR("fr_fr"),
    ES_AR("es_ar"),
    ES_CL("es_cl"),
    ES_EC("es_ec"),
    ES_ES("es_es"),
    ES_MX("es_mx"),
    ES_UY("es_uy"),
    ES_VE("es_ve"),
    EN_AU("en_au"),
    EN_CA("en_ca"),
    EN_NZ("en_nz"),
    DE_AT("de_at"),
    DE_CH("de_ch"),
    DE_DE("de_de"),
    NDS_DE("nds_de"),
    PT_BR("pt_br"),
    RU_RU("ru_ru"),
    UK_UA("uk_ua");

    private final String code;

    LanguageType(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
