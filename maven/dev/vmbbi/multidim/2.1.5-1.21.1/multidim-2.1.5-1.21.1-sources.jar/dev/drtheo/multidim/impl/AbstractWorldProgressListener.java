package dev.drtheo.multidim.impl;

import net.minecraft.class_2561;
import net.minecraft.class_3536;

public class AbstractWorldProgressListener implements class_3536 {

    @Override
    public void method_15412(class_2561 title) { }

    @Override
    public void method_15413(class_2561 title) { }

    @Override
    public void method_15414(class_2561 task) { }

    @Override
    public void method_15410(int percentage) { }

    @Override
    public void method_15411() { }
}
