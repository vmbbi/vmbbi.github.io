package dev.drtheo.multidim.api;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Lifecycle;
import dev.drtheo.multidim.impl.AbstractWorldGenListener;
import net.minecraft.class_156;
import net.minecraft.class_1937;
import net.minecraft.class_2370;
import net.minecraft.class_27;
import net.minecraft.class_2794;
import net.minecraft.class_2874;
import net.minecraft.class_2960;
import net.minecraft.class_32;
import net.minecraft.class_3949;
import net.minecraft.class_4543;
import net.minecraft.class_5219;
import net.minecraft.class_5268;
import net.minecraft.class_5304;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_8565;
import net.minecraft.class_9248;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Executor;

public class WorldBlueprint {

    private final class_2960 id;

    private long seed;
    private boolean tickTime = true;

    private class_2960 typeId;
    private class_2874 type;

    private WorldCreator creator = MultiDimServerWorld::new;
    private class_2794 generator;

    private boolean autoLoad = true;
    private boolean persistent = true;
    private class_5363 options;

    public WorldBlueprint(class_2960 id) {
        this.id = id;
    }

    public WorldBlueprint withSeed(long seed) {
        this.seed = class_4543.method_27984(seed);
        return this;
    }

    public long seed() {
        return this.seed;
    }

    public WorldBlueprint withCreator(WorldCreator creator) {
        this.creator = creator;
        return this;
    }

    public WorldBlueprint withType(class_2960 id) {
        this.typeId = id;
        return this;
    }

    public WorldBlueprint withType(class_2874 type) {
        return this.withType(null, type);
    }

    public WorldBlueprint withType(class_2960 id, class_2874 type) {
        this.typeId = id;
        this.type = type;
        return this;
    }

    public WorldBlueprint withGenerator(class_2794 generator) {
        this.generator = generator;
        return this;
    }

    public WorldBlueprint shouldTickTime(boolean tickTime) {
        this.tickTime = tickTime;
        return this;
    }

    public boolean shouldTickTime() {
        return this.tickTime;
    }

    public class_2960 id() {
        return this.id;
    }

    public WorldBlueprint setPersistent(boolean persistent) {
        this.persistent = persistent;
        return this;
    }

    public boolean persistent() {
        return this.persistent;
    }

    public WorldBlueprint setAutoLoad(boolean autoLoad) {
        this.autoLoad = autoLoad;
        return this;
    }

    public boolean autoLoad() {
        return autoLoad;
    }

    public MultiDimServerWorld createWorld(MinecraftServer server, class_5321<class_1937> key, class_5363 options, boolean created) {
        class_5219 saveProps = server.method_27728();

        return this.creator.create(
                this, server, class_156.method_18349(), ((MultiDimServer) server).multidim$getSession(),
                new class_27(saveProps, saveProps.method_27859()), key, options,
                new AbstractWorldGenListener(), ImmutableList.of(), null, created
        );
    }

    private class_6880<class_2874> resolveType(MinecraftServer server) {
        class_2370<class_2874> typeRegistry = (class_2370<class_2874>) server.method_30611().method_30530(class_7924.field_41241);

        if (this.typeId == null)
            this.typeId = this.id;

        class_5321<class_2874> typeKey = class_5321.method_29179(class_7924.field_41241, this.typeId);

        if (this.type == null) {
            class_6880<class_2874> entry = typeRegistry.method_40264(typeKey).orElse(null);

            if (entry == null)
                return null;

            this.type = entry.comp_349();
            return entry;
        }

        if (!typeRegistry.method_35842(typeKey))
            return typeRegistry.method_10272(
                    typeKey,
                    this.type,
                    new class_9248(
                            Optional.empty(),
                            Lifecycle.stable()
                    )
            );
        return typeRegistry.method_40264(typeKey).orElse(null);
    }

    public class_5363 createOptions(MinecraftServer server) {
        if (this.options != null) return this.options;

        class_6880<class_2874> typeEntry = this.resolveType(server);

        if (typeEntry == null)
            throw new IllegalArgumentException("Dimension type is required to create dimension options!");

        return new class_5363(typeEntry, this.generator);
    }

    public interface WorldCreator {
        MultiDimServerWorld create(WorldBlueprint blueprint, MinecraftServer server, Executor workerExecutor, class_32.class_5143 session, class_5268 properties, class_5321<class_1937> worldKey, class_5363 dimensionOptions, class_3949 worldGenerationProgressListener, List<class_5304> spawners, @Nullable class_8565 randomSequencesState, boolean created);
    }
}
