package dev.drtheo.multidim.util;

import dev.drtheo.multidim.api.MutableRegistry;
import net.minecraft.class_2370;
import net.minecraft.class_5363;
import net.minecraft.class_5455;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;


public class MultiDimUtil {

    public static class_2370<class_5363> getDimensionsRegistry(MinecraftServer server) {
        class_5455 registryManager = server.method_46221().method_45926();
        return (class_2370<class_5363>) registryManager.method_30530(class_7924.field_41224);
    }

    public static MutableRegistry<class_5363> getMutableDimensionsRegistry(MinecraftServer server) {
        return (MutableRegistry<class_5363>) getDimensionsRegistry(server);
    }
}
