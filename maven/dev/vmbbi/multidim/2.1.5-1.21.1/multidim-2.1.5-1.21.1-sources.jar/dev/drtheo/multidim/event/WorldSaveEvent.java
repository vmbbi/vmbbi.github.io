package dev.drtheo.multidim.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_3218;

public class WorldSaveEvent {

    public static final Event<Save> EVENT = EventFactory.createArrayBacked(Save.class, callbacks -> world -> {
        for (Save callback : callbacks) {
            callback.onWorldSave(world);
        }
    });

    @FunctionalInterface
    public interface Save {
        void onWorldSave(class_3218 world);
    }
}