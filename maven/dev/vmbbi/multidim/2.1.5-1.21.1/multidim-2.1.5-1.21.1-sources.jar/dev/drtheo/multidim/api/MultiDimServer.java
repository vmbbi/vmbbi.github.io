package dev.drtheo.multidim.api;

import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;

public interface MultiDimServer {
    void multidim$addWorld(class_3218 world);
    boolean multidim$hasWorld(class_5321<class_1937> key);
    class_3218 multidim$removeWorld(class_5321<class_1937> key);

    class_32.class_5143 multidim$getSession();
}
