package dev.drtheo.multidim.api;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import dev.drtheo.multidim.impl.AbstractChunkGenerator;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.minecraft.class_1311;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_1992;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_3195;
import net.minecraft.class_3218;
import net.minecraft.class_3485;
import net.minecraft.class_4966;
import net.minecraft.class_5138;
import net.minecraft.class_5281;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5483;
import net.minecraft.class_5539;
import net.minecraft.class_6012;
import net.minecraft.class_6748;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7059;
import net.minecraft.class_7138;
import net.minecraft.class_7225;
import net.minecraft.class_7869;

public class VoidChunkGenerator extends AbstractChunkGenerator {

    public static final MapCodec<VoidChunkGenerator> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            class_1959.field_24677.fieldOf("biome").forGetter(g -> g.biome)
    ).apply(instance, instance.stable(VoidChunkGenerator::new)));

    private static final class_4966 EMPTY_SAMPLE = new class_4966(0, new class_2680[0]);

    private final class_6880<class_1959> biome;

    public VoidChunkGenerator(class_6880<class_1959> biome) {
        super(new class_1992(biome));
        this.biome = biome;
    }

    public VoidChunkGenerator(class_2378<class_1959> biomeRegistry) {
        this(biomeRegistry, class_1972.field_9473);
    }

    public VoidChunkGenerator(class_2378<class_1959> biomeRegistry, class_5321<class_1959> biome) {
        this(biomeRegistry.method_40264(biome).orElseThrow());
    }

    @Override
    protected MapCodec<? extends class_2794> method_28506() {
        return CODEC;
    }

    @Override
    public void method_16130(class_5281 world, class_5138 accessor, class_2791 chunk) { }

    @Override
    public CompletableFuture<class_2791> method_12088(class_6748 blender, class_7138 noiseConfig, class_5138 structureAccessor, class_2791 chunk) {
        return CompletableFuture.completedFuture(chunk);
    }

    @Override
    public class_4966 method_26261(int x, int z, class_5539 world, class_7138 noiseConfig) {
        return EMPTY_SAMPLE;
    }

    @Override
    public void method_12102(class_5281 world, class_2791 chunk, class_5138 structureAccessor) { }

    @Nullable @Override
    public Pair<class_2338, class_6880<class_3195>> method_12103(class_3218 world, class_6885<class_3195> structures, class_2338 center, int radius, boolean skipReferencedStructures) {
        return null;
    }

    @Override
    public class_6012<class_5483.class_1964> method_12113(class_6880<class_1959> biome, class_5138 accessor, class_1311 group, class_2338 pos) {
        return class_6012.method_34990();
    }

    @Override
    public void method_16129(class_5455 registryManager, class_7869 placementCalculator, class_5138 structureAccessor, class_2791 chunk, class_3485 structureTemplateManager) { }

    @Override
    public class_7869 method_46696(class_7225<class_7059> structureSetRegistry, class_7138 noiseConfig, long seed) {
        return class_7869.method_46703(noiseConfig, seed, field_12761, Stream.empty());
    }
}