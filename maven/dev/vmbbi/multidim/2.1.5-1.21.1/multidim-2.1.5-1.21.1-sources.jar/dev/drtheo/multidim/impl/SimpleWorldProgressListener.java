package dev.drtheo.multidim.impl;

public class SimpleWorldProgressListener extends AbstractWorldProgressListener {

    private final Runnable onDone;

    public SimpleWorldProgressListener(Runnable onDone) {
        this.onDone = onDone;
    }

    @Override
    public void method_15411() {
        this.onDone.run();
    }
}
