package dev.drtheo.multidim.api;

import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3949;
import net.minecraft.class_5268;
import net.minecraft.class_5304;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_8565;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.concurrent.Executor;

public class MultiDimServerWorld extends class_3218 {

    private final WorldBlueprint blueprint;

    public MultiDimServerWorld(WorldBlueprint blueprint, MinecraftServer server, Executor workerExecutor, class_32.class_5143 session, class_5268 properties, class_5321<class_1937> worldKey, class_5363 dimensionOptions, class_3949 worldGenerationProgressListener, List<class_5304> spawners, @Nullable class_8565 randomSequencesState, boolean created) {
        super(server, workerExecutor, session, properties, worldKey, dimensionOptions, worldGenerationProgressListener, false, blueprint.seed(), spawners, blueprint.shouldTickTime(), randomSequencesState);

        this.blueprint = blueprint;
    }

    public WorldBlueprint getBlueprint() {
        return blueprint;
    }
}
