package dev.drtheo.multidim.impl;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1959;
import net.minecraft.class_1966;
import net.minecraft.class_2338;
import net.minecraft.class_2791;
import net.minecraft.class_2794;
import net.minecraft.class_2893;
import net.minecraft.class_2902;
import net.minecraft.class_3233;
import net.minecraft.class_4543;
import net.minecraft.class_5138;
import net.minecraft.class_5485;
import net.minecraft.class_5539;
import net.minecraft.class_6880;
import net.minecraft.class_7138;

public abstract class AbstractChunkGenerator extends class_2794 {

    public AbstractChunkGenerator(class_1966 biomeSource) {
        super(biomeSource);
    }

    public AbstractChunkGenerator(class_1966 biomeSource, Function<class_6880<class_1959>, class_5485> generationSettingsGetter) {
        super(biomeSource, generationSettingsGetter);
    }

    @Override
    public void method_12108(class_3233 chunkRegion, long seed, class_7138 noiseConfig, class_4543 biomeAccess, class_5138 structureAccessor, class_2791 chunk, class_2893.class_2894 carverStep) { }

    @Override
    public void method_12110(class_3233 region, class_5138 structures, class_7138 noiseConfig, class_2791 chunk) { }

    @Override
    public void method_12107(class_3233 region) { }

    @Override
    public int method_12104() {
        return 0;
    }

    @Override
    public int method_16398() {
        return 0;
    }

    @Override
    public int method_33730() {
        return 0;
    }

    @Override
    public int method_16397(int x, int z, class_2902.class_2903 heightmap, class_5539 world, class_7138 noiseConfig) {
        return 0;
    }

    @Override
    public void method_40450(List<String> text, class_7138 noiseConfig, class_2338 pos) { }
}
