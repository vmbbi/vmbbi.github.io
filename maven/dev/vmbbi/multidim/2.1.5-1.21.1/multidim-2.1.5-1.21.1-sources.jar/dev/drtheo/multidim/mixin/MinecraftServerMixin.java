package dev.drtheo.multidim.mixin;

import com.google.common.collect.Maps;
import dev.drtheo.multidim.MultiDimMod;
import dev.drtheo.multidim.api.MultiDimServer;
import dev.drtheo.multidim.event.ServerCrashEvent;
import net.minecraft.class_128;
import net.minecraft.class_1937;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_5321;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.LinkedHashMap;
import java.util.Map;

@Mixin(MinecraftServer.class)
public abstract class MinecraftServerMixin implements MultiDimServer {

    @Shadow @Final
    protected class_32.class_5143 session;

    @Shadow
    @Final
    @Mutable
    private Map<class_5321<class_1937>, class_3218> worlds;

    @Override
    public void multidim$addWorld(class_3218 world) {
        // use read-copy-update to avoid concurrency issues
        // from immersive portals
        LinkedHashMap<class_5321<class_1937>, class_3218> newMap =
                Maps.newLinkedHashMap();

        Map<class_5321<class_1937>, class_3218> oldMap = this.worlds;

        newMap.putAll(oldMap);
        newMap.put(world.method_27983(), world);

        this.worlds = newMap;
    }

    @Override
    public boolean multidim$hasWorld(class_5321<class_1937> key) {
        return this.worlds.containsKey(key);
    }

    @Override
    public class_3218 multidim$removeWorld(class_5321<class_1937> key) {
        // use read-copy-update to avoid concurrency issues
        // from immersive portals
        LinkedHashMap<class_5321<class_1937>, class_3218> newMap =
                Maps.newLinkedHashMap();

        Map<class_5321<class_1937>, class_3218> oldMap = this.worlds;

        for (Map.Entry<class_5321<class_1937>, class_3218> entry : oldMap.entrySet()) {
            if (entry.getKey() != key) {
                newMap.put(entry.getKey(), entry.getValue());
            }
        }

        this.worlds = newMap;

        return oldMap.get(key);
    }

    @Override
    public class_32.class_5143 multidim$getSession() {
        return this.session;
    }

    @Inject(method = "setCrashReport", at = @At("TAIL"))
    private void ait$setCrashReport(class_128 report, CallbackInfo info) {
        MultiDimMod.LOGGER.error("Crash Detected - nice one m8");
        ServerCrashEvent.EVENT.invoker().onServerCrash((MinecraftServer) (Object) this, report);
    }
}
