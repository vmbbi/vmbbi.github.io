package dev.drtheo.multidim.api;

import com.mojang.serialization.Lifecycle;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

public interface MutableRegistry<T> {
    boolean multidim$remove(T entry);
    boolean multidim$remove(class_2960 key);

    void multidim$freeze();
    void multidim$unfreeze();
    boolean multidim$isFrozen();

    boolean multidim$contains(class_5321<T> key);
    class_6880.class_6883<T> multidim$add(class_5321<T> key, T entry, Lifecycle lifecycle);
}
