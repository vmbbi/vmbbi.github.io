package dev.drtheo.multidim;

import com.mojang.serialization.Lifecycle;
import dev.drtheo.multidim.api.MultiDimServer;
import dev.drtheo.multidim.api.MultiDimServerWorld;
import dev.drtheo.multidim.api.MutableRegistry;
import dev.drtheo.multidim.api.WorldBlueprint;
import dev.drtheo.multidim.impl.SimpleWorldProgressListener;
import dev.drtheo.multidim.util.MultiDimUtil;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_32;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_5363;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MultiDim {

    private static MultiDim instance;
    private static boolean initialized = false;

    private final Map<class_2960, WorldBlueprint> blueprints = new HashMap<>();
    protected final MinecraftServer server;

    private final Set<class_3218> toDelete = new ReferenceOpenHashSet<>();
    private final Set<class_3218> toUnload = new ReferenceOpenHashSet<>();

    public static void init() {
        if (initialized)
            return;

        MultiDimFileManager.init();

        ServerTickEvents.START_SERVER_TICK.register(server -> MultiDim.get(server).tick());
        initialized = true;
    }

    private MultiDim(MinecraftServer server) {
        this.server = server;
    }

    private void tick() {
        Set<class_3218> deletionQueue = this.toDelete;

        if (!deletionQueue.isEmpty())
            deletionQueue.removeIf(this::tickDeleteWorld);

        Set<class_3218> unloadingQueue = this.toUnload;

        if (!unloadingQueue.isEmpty())
            unloadingQueue.removeIf(this::tickUnloadWorld);
    }

    public boolean isWorldUnloaded(class_3218 world) {
        return world.method_18456().isEmpty() && world.method_14178().method_14151() <= 0;
    }

    private boolean prepareForUnload(class_3218 world) {
        if (this.isWorldUnloaded(world))
            return true;

        this.kickPlayers(world);
        return false;
    }

    public void kickPlayers(class_3218 world) {
        if (world.method_18456().isEmpty())
            return;

        class_3218 overworld = this.server.method_30002();
        class_243 spawnPos = overworld.method_43126().method_46558();

        for (class_3222 player : world.method_18456()) {
            player.method_14251(overworld, spawnPos.method_10216(), spawnPos.method_10214(), spawnPos.method_10215(), player.method_36454(), player.method_36455());
        }
    }

    private boolean tickDeleteWorld(class_3218 world) {
        if (!this.prepareForUnload(world))
            return false;

        this.remove(world.method_27983());
        return true;
    }

    private boolean tickUnloadWorld(class_3218 world) {
        if (!this.prepareForUnload(world))
            return false;

        this.unload(world.method_27983());
        return true;
    }

    public void register(WorldBlueprint blueprint) {
        this.blueprints.put(blueprint.id(), blueprint);
    }

    public static MultiDim get(MinecraftServer server) {
        MultiDim.init();

        if (instance == null || instance.server != server)
            instance = new MultiDim(server);

        return instance;
    }

    public MultiDimServerWorld add(WorldBlueprint blueprint, class_2960 id) {
        return addOrLoad(blueprint, id, true);
    }

    public MultiDimServerWorld load(WorldBlueprint blueprint, class_2960 id) {
        return addOrLoad(blueprint, id, false);
    }

    public MultiDimServerWorld addOrLoad(WorldBlueprint blueprint, class_2960 id, boolean created) {
        return this.addOrLoad(blueprint, class_5321.method_29179(class_7924.field_41223, id), created);
    }

    public MultiDimServerWorld add(WorldBlueprint blueprint, class_5321<class_1937> id) {
        return addOrLoad(blueprint, id, true);
    }

    public MultiDimServerWorld load(WorldBlueprint blueprint, class_5321<class_1937> id) {
        return addOrLoad(blueprint, id, false);
    }

    public MultiDimServerWorld addOrLoad(WorldBlueprint blueprint, class_5321<class_1937> id, boolean created) {
        class_3218 existing = this.server.method_3847(id);

        if (existing != null)
            return (MultiDimServerWorld) existing;

        MutableRegistry<class_5363> dimensionsRegistry = MultiDimUtil.getMutableDimensionsRegistry(this.server);
        boolean wasFrozen = dimensionsRegistry.multidim$isFrozen();

        if (wasFrozen)
            dimensionsRegistry.multidim$unfreeze();

        class_5363 options = blueprint.createOptions(this.server);
        class_5321<class_5363> key = class_5321.method_29179(class_7924.field_41224, options.comp_1012()
                .method_40230().map(class_5321::method_29177).orElse(blueprint.id()));

        if (!dimensionsRegistry.multidim$contains(key))
            dimensionsRegistry.multidim$add(key, options, Lifecycle.stable());

        if (wasFrozen)
            dimensionsRegistry.multidim$freeze();

        MultiDimServerWorld world = blueprint.createWorld(this.server, id, options, created);
        this.load(world);

        return world;
    }

    public void queueUnload(MultiDimServerWorld world) {
        this.toUnload.add(world);
    }

    public void queueUnload(class_5321<class_1937> key) {
        this.toUnload.add(this.server.method_3847(key));
    }

    private void unload(class_5321<class_1937> key) {
        class_3218 world = ((MultiDimServer) this.server).multidim$removeWorld(key);

        if (world == null)
            return;

        world.method_14176(new SimpleWorldProgressListener(() -> {
            ServerWorldEvents.UNLOAD.invoker().onWorldUnload(this.server, world);
            MultiDimUtil.getMutableDimensionsRegistry(this.server).multidim$remove(key.method_29177());
        }), true, false);
    }

    public void queueRemove(MultiDimServerWorld world) {
        this.toDelete.add(world);
    }

    public void queueRemove(class_5321<class_1937> key) {
        this.toDelete.add(this.server.method_3847(key));
    }

    private void remove(class_5321<class_1937> key) {
        class_3218 world = ((MultiDimServer) this.server).multidim$removeWorld(key);

        if (world == null)
            return;

        ServerWorldEvents.UNLOAD.invoker().onWorldUnload(this.server, world);
        MultiDimUtil.getMutableDimensionsRegistry(this.server).multidim$remove(key.method_29177());

        class_32.class_5143 session = ((MultiDimServer) this.server).multidim$getSession();
        File worldDirectory = session.method_27424(key).toFile();

        if (!worldDirectory.exists())
            return;

        try {
            FileUtils.deleteDirectory(worldDirectory);
        } catch (IOException e) {
            MultiDimMod.LOGGER.warn("Failed to delete world directory", e);

            try {
                FileUtils.forceDeleteOnExit(worldDirectory);
            } catch (IOException ignored) { }
        }
    }

    private void load(MultiDimServerWorld world) {
        MultiDimMod.LOGGER.info("Loading world {}", world.method_27983().method_29177());

        if (((MultiDimServer) this.server).multidim$hasWorld(world.method_27983())) {
            MultiDimMod.LOGGER.warn("World {} is already loaded", world.method_27983().method_29177());
            return;
        }

        ((MultiDimServer) this.server).multidim$addWorld(world);

        ServerWorldEvents.LOAD.invoker().onWorldLoad(this.server, world);
        world.method_18765(() -> true);
    }

    public WorldBlueprint getBlueprint(class_2960 id) {
        return blueprints.get(id);
    }
}
