package dev.drtheo.multidim.mixin;

import dev.drtheo.multidim.api.MutableRegistry;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.ObjectList;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Map;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_9248;

@Mixin(class_2370.class)
public abstract class SimpleRegistryMixin<T> implements MutableRegistry<T> {

    @Shadow @Final private Map<T, class_6880.class_6883<T>> valueToEntry;

    @Shadow @Final private Object2IntMap<T> entryToRawId;

    @Shadow @Final private ObjectList<class_6880.class_6883<T>> rawIdToEntry;

    @Shadow @Final private Map<class_5321<T>, class_6880.class_6883<T>> keyToEntry;

    @Shadow @Final private Map<T, class_9248> keyToEntryInfo;

    @Shadow private boolean frozen;

    @Shadow public abstract class_5321<? extends class_2378<T>> getKey();

    @Shadow public abstract class_6880.class_6883<T> add(class_5321<T> key, T value, class_9248 info);

    @Shadow public abstract boolean contains(class_5321<T> key);

    @Override
    public boolean multidim$remove(T entry) {
        class_6880.class_6883<T> registryEntry = this.valueToEntry.get(entry);
        if (registryEntry == null)
            return false;

        int rawId = this.entryToRawId.removeInt(entry);
        if (rawId == -1)
            return false;

        try {
            this.rawIdToEntry.set(rawId, null);

            this.keyToEntry.remove(registryEntry.method_40237());
            this.keyToEntryInfo.remove(entry);
            this.valueToEntry.remove(entry);

            return true;
        } catch (Throwable e) {
            e.printStackTrace();
        }

        return false;
    }

    @Override
    public boolean multidim$remove(class_2960 key) {
        class_5321<T> registryKey = class_5321.method_29179(this.getKey(), key);
        class_6880.class_6883<T> entry = this.keyToEntry.get(registryKey);

        return entry != null && entry.method_40227() && this.multidim$remove(entry.comp_349());
    }

    @Override
    public void multidim$freeze() {
        this.frozen = true;
    }

    @Override
    public void multidim$unfreeze() {
        this.frozen = false;
    }

    @Override
    public boolean multidim$isFrozen() {
        return this.frozen;
    }

    @Override
    public boolean multidim$contains(class_5321<T> key) {
        return this.contains(key);
    }

    @Override
    public class_6880.class_6883<T> multidim$add(class_5321<T> key, T value, class_9248 info) {
        return this.add(key, value, info);
    }
}