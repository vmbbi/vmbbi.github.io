package dev.amble.lib.container.impl;

import dev.amble.lib.container.RegistryContainer;
import net.minecraft.class_1535;
import net.minecraft.class_2378;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_7924;

public interface PaintingContainer extends RegistryContainer<class_1535> {

    @Override
    default Class<class_1535> getTargetClass() {
        return class_1535.class;
    }

    default class_5321<class_2378<class_1535>> getRegistryKey() {
        return class_7924.field_41209;
    }

    default class_2378<class_1535> getRegistry(class_5455 registryManager) {
        return registryManager.method_30530(class_7924.field_41209);
    }
}