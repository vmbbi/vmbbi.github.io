package dev.amble.lib.skin;

import dev.amble.lib.AmbleKit;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record SkinSyncPayload(Map<UUID, SkinData> skins) implements class_8710 {
    public static final class_8710.class_9154<SkinSyncPayload> ID = new class_8710.class_9154<>(AmbleKit.id("skin_sync"));

    public static final class_9139<class_9129, SkinSyncPayload> CODEC = class_8710.method_56484(
            SkinSyncPayload::write,
            SkinSyncPayload::new
    );

    public SkinSyncPayload(class_9129 buf) {
        this(readSkins(buf));
    }

    private static Map<UUID, SkinData> readSkins(class_9129 buf) {
        int count = buf.readInt();
        Map<UUID, SkinData> map = new HashMap<>();
        for (int i = 0; i < count; i++) {
            UUID id = buf.method_10790();
            SkinData data = SkinData.readBuf(buf);
            if (data != null) {
                map.put(id, data);
            }
        }
        return map;
    }

    private void write(class_9129 buf) {
        buf.method_53002(skins.size());
        for (Map.Entry<UUID, SkinData> entry : skins.entrySet()) {
            buf.method_10797(entry.getKey());
            entry.getValue().writeBuf(buf);
        }
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}