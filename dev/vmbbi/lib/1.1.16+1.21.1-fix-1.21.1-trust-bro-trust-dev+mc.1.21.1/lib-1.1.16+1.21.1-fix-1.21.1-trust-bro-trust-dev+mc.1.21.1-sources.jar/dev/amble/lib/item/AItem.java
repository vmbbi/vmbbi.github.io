package dev.amble.lib.item;

import net.minecraft.class_1761;

public interface AItem {
    class_1761 amble$group();
}
