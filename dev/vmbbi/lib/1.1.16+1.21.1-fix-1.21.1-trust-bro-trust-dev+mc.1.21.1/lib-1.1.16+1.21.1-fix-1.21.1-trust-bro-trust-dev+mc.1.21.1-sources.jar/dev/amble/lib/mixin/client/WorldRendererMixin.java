package dev.amble.lib.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.animation.client.AnimationMetadata;
import dev.amble.lib.client.bedrock.BedrockAnimation;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4599;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import net.minecraft.class_9779;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public class WorldRendererMixin {

	@Final
	@Shadow
	private class_4599 bufferBuilders;

	@Inject(
			method = "render",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/client/render/WorldRenderer;checkEmpty(Lnet/minecraft/client/util/math/MatrixStack;)V",
					ordinal = 0
			)
	)
	public void render(
			class_9779 tickCounter,
			boolean renderBlockOutline,
			class_4184 camera,
			class_757 gameRenderer,
			class_765 lightmapTextureManager,
			Matrix4f positionMatrix,
			Matrix4f projectionMatrix,
			CallbackInfo ci,
			@Local class_4587 matrices
	) {
		if (!(camera.method_19331() instanceof AnimatedEntity animated)) return;

		BedrockAnimation anim = BedrockAnimation.getFor(animated);
		
		if (anim == null) {
			BedrockAnimation.IS_RENDERING_HEAD = null;
			return;
		}
		
		AnimationMetadata metadata = anim.metadata;
		
		if (metadata == null || !metadata.fpsCamera()) {
			BedrockAnimation.IS_RENDERING_HEAD = null;
			return;
		}

		boolean thirdPerson = camera.method_19333();
		boolean hasCamera = anim.boneTimelines.containsKey("camera");
		boolean isNear = camera.method_19326().method_1022(camera.method_19331().method_19538().method_1031(0, camera.method_19331().method_5751(), 0)) <= BedrockAnimation.HEAD_HIDE_DISTANCE;

		class_243 vec3d = camera.method_19326();
		double d = vec3d.field_1352;
		double e = vec3d.field_1351;
		double f = vec3d.field_1350;
		class_4597.class_4598 immediate = this.bufferBuilders.method_23000();
		float tickDelta = tickCounter.method_60637(true);
		BedrockAnimation.IS_RENDERING_PLAYER = true;
		BedrockAnimation.IS_RENDERING_HEAD = thirdPerson && hasCamera && !isNear;
		this.renderEntity(camera.method_19331(), d, e, f, tickDelta, matrices, immediate);
		BedrockAnimation.IS_RENDERING_PLAYER = false;
	}

	@Shadow
	private void renderEntity(class_1297 entity, double cameraX, double cameraY, double cameraZ, float tickDelta,
							  class_4587 matrices, class_4597 vertexConsumers) {

	}
}