package dev.amble.lib.animation;

import dev.amble.lib.AmbleKit;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record AnimationSyncPayload(Map<UUID, class_2960> animations, UUID removedId, boolean isRemoval) implements class_8710 {
    public static final class_8710.class_9154<AnimationSyncPayload> ID = new class_8710.class_9154<>(AmbleKit.id("animation_sync"));

    public static final class_9139<class_9129, AnimationSyncPayload> CODEC = class_8710.method_56484(
            AnimationSyncPayload::write,
            AnimationSyncPayload::new
    );

    public AnimationSyncPayload(class_9129 buf) {
        this(readAnimations(buf), buf.readBoolean() ? buf.method_10790() : null, buf.readBoolean());
    }

    private static Map<UUID, class_2960> readAnimations(class_9129 buf) {
        int count = buf.readInt();
        Map<UUID, class_2960> map = new HashMap<>();
        for (int i = 0; i < count; i++) {
            map.put(buf.method_10790(), buf.method_10810());
        }
        return map;
    }

    private void write(class_9129 buf) {
        buf.method_53002(animations.size());
        for (Map.Entry<UUID, class_2960> entry : animations.entrySet()) {
            buf.method_10797(entry.getKey());
            buf.method_10812(entry.getValue());
        }
        buf.method_52964(removedId != null);
        if (removedId != null) {
            buf.method_10797(removedId);
        }
        buf.method_52964(isRemoval);
    }

    @Override
    public class_8710.class_9154<? extends class_8710> method_56479() {
        return ID;
    }
}