package dev.amble.lib.client.bedrock;

import net.minecraft.class_4587;
import net.minecraft.class_4588;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public record BedrockPerFaceQuad(
        Vector3f p0, Vector3f p1, Vector3f p2, Vector3f p3,
        float u0, float v0, float u1, float v1,
        Vector3f normal
) {
    public void render(class_4587.class_4665 entry, class_4588 vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        Matrix4f position = entry.method_23761();
        Matrix3f normalMat = entry.method_23762();

        Vector3f n = new Vector3f(normal);
        n.mul(normalMat);

        vertex(vertices, position, p0, u0, v0, n, light, overlay, red, green, blue, alpha);
        vertex(vertices, position, p1, u1, v0, n, light, overlay, red, green, blue, alpha);
        vertex(vertices, position, p2, u1, v1, n, light, overlay, red, green, blue, alpha);
        vertex(vertices, position, p3, u0, v1, n, light, overlay, red, green, blue, alpha);
    }

    private static void vertex(class_4588 vc, Matrix4f pos, Vector3f p,
                               float u, float v, Vector3f n,
                               int light, int overlay,
                               float red, float green, float blue, float alpha) {
        vc.method_22918(pos, p.x(), p.y(), p.z())
                .method_22915(red, green, blue, alpha)
                .method_22913(u, v)
                .method_22922(overlay)
                .method_60803(light)
                .method_22914(n.x(), n.y(), n.z());
    }
}