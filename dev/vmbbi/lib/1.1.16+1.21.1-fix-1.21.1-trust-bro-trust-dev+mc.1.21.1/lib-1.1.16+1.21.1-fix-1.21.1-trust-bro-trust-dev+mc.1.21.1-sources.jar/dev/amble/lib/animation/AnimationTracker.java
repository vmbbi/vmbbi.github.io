package dev.amble.lib.animation;

import dev.amble.lib.client.bedrock.BedrockAnimationReference;
import dev.amble.lib.util.ServerLifecycleHooks;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;

import java.util.*;

public class AnimationTracker {
	private static final AnimationTracker INSTANCE = new AnimationTracker();

	public static AnimationTracker getInstance() {
		return INSTANCE;
	}

	public static void init() {
		// Register Payload Codec
		PayloadTypeRegistry.playS2C().register(AnimationSyncPayload.ID, AnimationSyncPayload.CODEC);

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			getInstance().sync(handler.method_32311());
		});

		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			initClient();
		}
	}

	@Environment(EnvType.CLIENT)
	private static void initClient() {
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> getInstance().clear());

		ClientPlayNetworking.registerGlobalReceiver(AnimationSyncPayload.ID, (payload, context) -> {
			context.client().execute(() -> getInstance().receive(payload));
		});
	}

	private final Map<UUID, BedrockAnimationReference> animations = new HashMap<>();
	private final Set<UUID> updated = new HashSet<>();

	@Nullable
	public BedrockAnimationReference get(AnimatedInstance entity) {
		return this.animations.get(entity.getUuid());
	}

	public void add(UUID id, BedrockAnimationReference animation) {
		this.animations.put(id, animation);
		sync(new AnimationSyncPayload(Map.of(id, animation.id()), null, false));
	}

	public void add(AnimatedInstance entity, BedrockAnimationReference animation) {
		this.add(entity.getUuid(), animation);
	}

	public void removeLocal(UUID id) {
		this.animations.remove(id);
	}

	public void removeLocal(AnimatedInstance entity) {
		this.removeLocal(entity.getUuid());
	}

	public void remove(UUID id) {
		this.removeLocal(id);
		sync(new AnimationSyncPayload(Map.of(), id, true));
	}

	public void remove(AnimatedInstance entity) {
		this.remove(entity.getUuid());
	}

	public boolean isDirty(AnimatedInstance entity) {
		return this.updated.remove(entity.getUuid());
	}

	private void clear() {
		this.animations.clear();
		this.updated.clear();
	}

	private void receive(AnimationSyncPayload payload) {
		if (payload.isRemoval() && payload.removedId() != null) {
			this.animations.remove(payload.removedId());
			return;
		}

		for (Map.Entry<UUID, class_2960> entry : payload.animations().entrySet()) {
			BedrockAnimationReference reference = BedrockAnimationReference.parse(entry.getValue());
			this.animations.put(entry.getKey(), reference);
			this.updated.add(entry.getKey());
		}
	}

	public void sync() {
		Map<UUID, class_2960> map = new HashMap<>();
		this.animations.forEach((uuid, ref) -> map.put(uuid, ref.id()));
		sync(new AnimationSyncPayload(map, null, false));
	}

	public void sync(class_3222 target) {
		Map<UUID, class_2960> map = new HashMap<>();
		this.animations.forEach((uuid, ref) -> map.put(uuid, ref.id()));
		sync(new AnimationSyncPayload(map, null, false), target);
	}

	private void sync(AnimationSyncPayload payload) {
		ServerLifecycleHooks.get().method_3760().method_14571().forEach(p -> this.sync(payload, p));
	}

	private void sync(AnimationSyncPayload payload, class_3222 player) {
		ServerPlayNetworking.send(player, payload);
	}
}