package dev.amble.lib.client.bedrock;

import com.mojang.serialization.Codec;
import dev.amble.lib.api.Identifiable;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import java.util.Optional;

public record BedrockModelReference(String fileName, String animationName) implements Identifiable {
	public static Codec<BedrockModelReference> CODEC = class_2960.field_25139.xmap(
			BedrockModelReference::parse,
			BedrockModelReference::id
	);

	@Override
	public class_2960 id() {
		return class_2960.method_60655(fileName, animationName);
	}

	@Environment(EnvType.CLIENT)
	public Optional<BedrockModel> get() {
		BedrockModel animation = BedrockModelRegistry.getInstance().get(this.id());
		return Optional.ofNullable(animation);
	}

	public static BedrockModelReference parse(class_2960 id) {
		return new BedrockModelReference(id.method_12836(), id.method_12832());
	}
}
