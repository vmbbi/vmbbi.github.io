package dev.amble.lib.mixin.client;

import dev.amble.lib.skin.SkinData;
import dev.amble.lib.skin.SkinTracker;
import dev.amble.lib.skin.client.SkinGrabber;
import net.minecraft.class_2960;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_742.class)
public abstract class AbstractClientPlayerMixin {
	@Unique @Nullable private SkinData lastSkin = null;

	@Inject(method = "getSkinTextures", at = @At("RETURN"), cancellable = true)
	private void amblekit$getSkinTextures(CallbackInfoReturnable<class_8685> cir) {
		class_742 player = (class_742) (Object) this;

		SkinTracker tracker = SkinTracker.getInstance();
		SkinData data = tracker.get(player.method_5667());
		if (data == null) return;

		class_2960 id = data.get();
		if (id == null) return;

		if (SkinGrabber.isMissingTexture(id) && lastSkin != null) {
			id = lastSkin.get();
		} else {
			lastSkin = data;
		}

		class_8685 original = cir.getReturnValue();
		class_8685.class_7920 model = data.slim() ? class_8685.class_7920.field_41122 : class_8685.class_7920.field_41123;

		class_8685 customTextures = new class_8685(
				id,
				original != null ? original.comp_1911() : null,
				original != null ? original.comp_1627() : null,
				original != null ? original.comp_1628() : null,
				model,
				original != null && original.comp_1630()
		);

		cir.setReturnValue(customTextures);
	}
}