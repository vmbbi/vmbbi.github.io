package dev.amble.lib.itemgroup;

import java.util.function.Supplier;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class AItemGroup extends class_1761 {

    private final class_2960 id;

    protected AItemGroup(class_2960 id, class_7915 row, int column, class_7916 type, class_2561 displayName, Supplier<class_1799> iconSupplier, class_7914 entryCollector) {
        super(row, column, type, displayName, iconSupplier, entryCollector);

        this.id = id;
    }

    public class_2960 id() {
        return id;
    }

    public static Builder builder(class_2960 id) {
        return new Builder(id);
    }

    public static class Builder {

        private static final class_7914 EMPTY_ENTRIES = (displayContext, entries) -> {};
        private class_2561 displayName = null;
        private Supplier<class_1799> iconSupplier = () -> class_1799.field_8037;

        private class_7914 entryCollector = EMPTY_ENTRIES;
        private boolean scrollbar = true;
        private boolean renderName = true;
        private boolean special = false;
        private class_7916 type = class_7916.field_41052;
        private String texture = "items.png";

        private final class_2960 id;

        public Builder(class_2960 id) {
            this.id = id;
        }

        public Builder displayName(class_2561 displayName) {
            this.displayName = displayName;
            return this;
        }

        public Builder icon(Supplier<class_1799> iconSupplier) {
            this.iconSupplier = iconSupplier;
            return this;
        }

        public Builder entries(class_7914 entryCollector) {
            this.entryCollector = entryCollector;
            return this;
        }

        public Builder special() {
            this.special = true;
            return this;
        }

        public Builder noRenderedName() {
            this.renderName = false;
            return this;
        }

        public Builder noScrollbar() {
            this.scrollbar = false;
            return this;
        }

        protected Builder type(class_7916 type) {
            this.type = type;
            return this;
        }

        public Builder texture(String texture) {
            this.texture = texture;
            return this;
        }

        public AItemGroup build() {
            if ((this.type == class_7916.field_41054 || this.type == class_7916.field_41053) && this.entryCollector != EMPTY_ENTRIES) {
                throw new IllegalStateException("Special tabs can't have display items");
            }

            if (this.displayName == null)
                this.displayName = class_2561.method_43471("itemGroup." + id.method_12836() + "." + id.method_12832());

            AItemGroup itemGroup = new AItemGroup(this.id, null, -1, this.type, this.displayName, this.iconSupplier, this.entryCollector);

            itemGroup.field_41031 = this.special;
            itemGroup.field_7917 = this.renderName;
            itemGroup.field_7920 = this.scrollbar;
            return itemGroup;
        }
    }
}
