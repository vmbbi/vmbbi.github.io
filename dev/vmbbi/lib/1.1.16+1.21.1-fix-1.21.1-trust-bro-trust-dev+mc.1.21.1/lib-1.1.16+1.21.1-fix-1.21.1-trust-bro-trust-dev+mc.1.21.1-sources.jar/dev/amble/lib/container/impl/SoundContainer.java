package dev.amble.lib.container.impl;

import dev.amble.lib.container.RegistryContainer;
import net.minecraft.class_2378;
import net.minecraft.class_3414;
import net.minecraft.class_7923;

public interface SoundContainer extends RegistryContainer<class_3414> {

    @Override
    default class_2378<class_3414> getRegistry() {
        return class_7923.field_41172;
    }

    @Override
    default Class<class_3414> getTargetClass() {
        return class_3414.class;
    }
}
