package dev.amble.lib.animation.client;

import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.client.bedrock.BedrockEntityModel;
import dev.amble.lib.client.bedrock.BedrockModel;
import dev.amble.lib.client.bedrock.BedrockModelReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import net.minecraft.class_922;

@Environment(EnvType.CLIENT)
public class BedrockEntityRenderer<T extends class_1309 & AnimatedEntity> extends class_922<T, BedrockEntityModel<T>> {
	public BedrockEntityRenderer(class_5617.class_5618 ctx, float shadowRadius) {
		super(ctx, null, shadowRadius);
	}

	public BedrockEntityRenderer(class_5617.class_5618 ctx) {
		this(ctx, 0.5f);
	}

	@Override
	public void method_4054(T livingEntity, float f, float g, class_4587 matrices, class_4597 vertexConsumerProvider, int i) {
		if (this.field_4737 == null) this.refreshModel(livingEntity);

		matrices.method_22903();

		matrices.method_22904(0.0D, -1.5D, 0.0D);
		super.method_4054(livingEntity, f, g, matrices, vertexConsumerProvider, i);

		matrices.method_22909();
	}


	protected void renderLabelIfPresent(T entity, class_2561 text, class_4587 matrices, class_4597 vertexConsumers, int light) {
		matrices.method_22903();
		matrices.method_22904(0, 1.5D, 0);
		super.method_3926(entity, text, matrices, vertexConsumers, light, 0.0f);
		matrices.method_22909();
	}

	@Override
	public class_2960 getTexture(T entity) {
		return entity.getTexture();
	}

	protected BedrockEntityModel<T> refreshModel(T entity) {
		BedrockModelReference ref = entity.getModel();
		if (ref == null) throw new IllegalStateException("Entity " + entity + " does not have a BedrockModelReference");
		BedrockModel bedrock = ref.get().orElseThrow(() -> new IllegalStateException("BedrockModel " + ref.id() + " not found for entity " + entity));

		this.field_4737 = new BedrockEntityModel<>(bedrock);
		return this.field_4737;
	}
}
