package dev.amble.lib.skin;

import dev.amble.lib.skin.client.SkinGrabber;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_5568;

public interface PlayerSkinTexturable extends class_5568 {
	default SkinData getSkin() {
		return SkinTracker.getInstance().get(this.method_5667());
	}

	default void setSkin(SkinData skin) {
		skin.upload(this);
	}

	@Environment(EnvType.CLIENT)
	default class_2960 getSkinTexture() {
		SkinData skin = this.getSkin();
		if (skin == null) return SkinGrabber.missing();
		return skin.get();
	}
}
