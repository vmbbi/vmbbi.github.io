
package dev.amble.lib.mixin.client;

import dev.amble.lib.client.bedrock.BedrockAnimation;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_572;
import net.minecraft.class_970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = class_970.class, priority = 100)
public abstract class ArmorFeatureRendererMixin<T extends class_1309, M extends class_572<T>, A extends class_572<T>>
        extends class_3887<T, M> {

	public ArmorFeatureRendererMixin(class_3883<T, M> context) {
		super(context);
	}

	@Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true)
    private void renderArmor(class_4587 matrices, class_4597 vertexConsumers, T entity, class_1304 armorSlot, int light, A model, CallbackInfo ci) {
        if (entity != class_310.method_1551().field_1719) {
            return;
        }

        if (armorSlot == class_1304.field_6169 && BedrockAnimation.IS_RENDERING_PLAYER && BedrockAnimation.IS_RENDERING_HEAD == false) {
            ci.cancel();
        }
    }

}
