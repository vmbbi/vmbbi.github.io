package dev.amble.lib.mixin;

import dev.amble.lib.blockentity.StructurePlaceableBlockEntity;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_3499;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_3499.class)
public class StructureTemplateMixin {

    @Redirect(method = "place", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/entity/BlockEntity;read(Lnet/minecraft/nbt/NbtCompound;Lnet/minecraft/registry/RegistryWrapper$WrapperLookup;)V"))
    public void place(class_2586 blockEntity, class_2487 nbt, net.minecraft.class_7225.class_7874 lookup) {
        if (blockEntity instanceof StructurePlaceableBlockEntity placeable) placeable.amble$onStructurePlaced(nbt);

        blockEntity.method_58690(nbt, lookup);
    }
}