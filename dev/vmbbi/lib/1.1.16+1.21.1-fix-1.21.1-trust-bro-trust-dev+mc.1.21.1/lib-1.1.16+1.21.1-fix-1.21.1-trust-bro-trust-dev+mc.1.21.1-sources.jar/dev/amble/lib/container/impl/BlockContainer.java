package dev.amble.lib.container.impl;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;
import dev.amble.lib.block.ABlockSettings;
import dev.amble.lib.container.RegistryContainer;
import dev.amble.lib.item.AItem;
import dev.amble.lib.mixin.AbstractBlockAccessor;

public abstract class BlockContainer implements RegistryContainer<class_2248> {

    protected List<class_1792> items;

    @Override
    public void start(int fields) {
        this.items = new ArrayList<>(fields);
    }

    @Override
    public Class<class_2248> getTargetClass() {
        return class_2248.class;
    }

    @Override
    public class_2378<class_2248> getRegistry() {
        return class_7923.field_41175;
    }

    @Override
    public void postProcessField(class_2960 identifier, class_2248 value, Field field) {
        if (field.isAnnotationPresent(NoBlockItem.class))
            return;

        class_1792.class_1793 itemSettings = null;

        if (((AbstractBlockAccessor) value).getSettings() instanceof ABlockSettings abs)
            itemSettings = abs.itemSettings();

        class_1792 item = this.createBlockItem(value, itemSettings);
        class_2378.method_10230(class_7923.field_41178, identifier, item);

        this.items.add(item);
    }

    @Override
    public void finish() {
        ItemGroupEvents.MODIFY_ENTRIES_ALL.register((group, entries) -> {
            for (class_1792 item : items) {
                if (((AItem) item).amble$group() == group)
                    entries.method_45421(item);
            }
        });
    }

    public class_1747 createBlockItem(class_2248 block, @Nullable class_1792.class_1793 settings) {
        return new class_1747(block, settings == null ? this.createBlockItemSettings(block) : settings);
    }

    public class_1792.class_1793 createBlockItemSettings(class_2248 block) {
        return new class_1792.class_1793();
    }
}
