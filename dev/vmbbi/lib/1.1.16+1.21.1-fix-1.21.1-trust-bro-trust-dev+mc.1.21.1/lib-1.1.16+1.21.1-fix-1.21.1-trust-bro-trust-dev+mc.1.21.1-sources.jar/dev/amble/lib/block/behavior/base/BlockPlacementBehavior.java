package dev.amble.lib.block.behavior.base;

import dev.amble.lib.block.behavior.api.BlockBehavior;
import dev.amble.lib.block.behavior.api.BlockBehaviors;
import net.minecraft.class_1750;
import net.minecraft.class_2680;

public class BlockPlacementBehavior implements BlockBehavior {

    public class_2680 getPlacementState(class_2680 state, class_1750 ctx) {
        return state;
    }

    @Override
    public int idx() {
        return BlockBehaviors.BLOCK_PLACEMENT;
    }
}
