package dev.amble.lib.register.datapack;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import dev.amble.lib.AmbleKit;
import dev.amble.lib.api.Identifiable;
import dev.amble.lib.util.ServerLifecycleHooks;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_3264;
import net.minecraft.class_3300;
import net.minecraft.class_8710;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public abstract class SimpleDatapackRegistry<T extends Identifiable> extends DatapackRegistry<T>
        implements SimpleSynchronousResourceReloadListener {

    public record DatapackPayload<T extends Identifiable>(
            class_8710.class_9154<DatapackPayload<T>> payloadId,
            List<T> items
    ) implements class_8710 {
        @Override
        public class_8710.class_9154<? extends class_8710> method_56479() {
            return payloadId;
        }
    }

    private final Function<InputStream, T> deserializer;
    private final Codec<T> codec;
    protected final class_8710.class_9154<DatapackPayload<T>> payloadId;
    private final class_2960 name;
    private final boolean sync;

    public SimpleDatapackRegistry(Function<InputStream, T> deserializer, Codec<T> codec, class_2960 packet,
                                  class_2960 name, boolean sync) {
        this.deserializer = deserializer;
        this.codec = codec;
        this.payloadId = new class_8710.class_9154<>(packet);
        this.name = name;
        this.sync = sync;
    }

    protected SimpleDatapackRegistry(Function<InputStream, T> deserializer, Codec<T> codec, String packet, String name,
                                     boolean sync, String modid) {
        this(deserializer, codec, class_2960.method_60655(modid, "sync_" + packet), class_2960.method_60655(modid, name), sync);
    }

    protected SimpleDatapackRegistry(Function<InputStream, T> deserializer, Codec<T> codec, String name, boolean sync, String modid) {
        this(deserializer, codec, name, name, sync, modid);
    }

    /**
     * @deprecated Use {@link #SimpleDatapackRegistry(Function, Codec, String, boolean, String)} instead and provide your own modid
     */
    @Deprecated(forRemoval = true, since = "1.0.11")
    protected SimpleDatapackRegistry(Function<InputStream, T> deserializer, Codec<T> codec, String name) {
        this(deserializer, codec, name, name, true, AmbleKit.MOD_ID);
    }

    public void onClientInit() {
        if (!this.sync)
            return;

        ClientPlayNetworking.registerGlobalReceiver(this.payloadId, (payload, context) -> {
            context.client().execute(() -> this.readFromServer(payload.items()));
        });

        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            this.clearCache();
            this.defaults();
        });
    }

    public void onServerInit() {
    }

    public void onCommonInit() {
        ResourceManagerHelper.get(class_3264.field_14190).registerReloadListener(this);

        if (!this.sync)
            return;

        ServerLifecycleEvents.SYNC_DATA_PACK_CONTENTS.register((player, joined) -> this.syncToClient(player));
    }

    @Override
    public void syncToEveryone() {
        if (!this.sync || ServerLifecycleHooks.get() == null)
            return;

        super.syncToEveryone();
    }

    @Override
    public void syncToClient(class_3222 player) {
        if (!this.sync)
            return;

        List<T> items = new ArrayList<>(REGISTRY.values());
        DatapackPayload<T> payload = new DatapackPayload<>(this.payloadId, items);

        ServerPlayNetworking.send(player, payload);
    }

    public void readFromServer(List<T> items) {
        if (!this.sync)
            return;

        this.clearCache();
        this.defaults();

        for (T item : items) {
            this.register(item);
        }

        AmbleKit.LOGGER.info("Read {} {} from server", items.size(), this.name);
    }

    protected abstract void defaults();

    protected T read(InputStream stream) {
        return this.deserializer.apply(stream);
    }

    @Override
    public class_2960 getFabricId() {
        return SimpleDatapackRegistry.this.name;
    }

    @Override
    public void method_14491(class_3300 manager) {
        this.defaults();

        manager.method_14488(this.name.method_12832(), filename -> filename.method_12832().endsWith(".json"))
                .forEach((id, resource) -> {
                    try (InputStream stream = resource.method_14482()) {
                        T created = this.read(stream);

                        if (created != null) {
                            this.register(created);
                            AmbleKit.LOGGER.info("Loaded datapack {} {}", this.name, created.id().toString());
                        }
                    } catch (Exception e) {
                        AmbleKit.LOGGER.error("Error occurred while loading resource json {}", id.toString(), e);
                    }
                });

        this.syncToEveryone();
    }
}