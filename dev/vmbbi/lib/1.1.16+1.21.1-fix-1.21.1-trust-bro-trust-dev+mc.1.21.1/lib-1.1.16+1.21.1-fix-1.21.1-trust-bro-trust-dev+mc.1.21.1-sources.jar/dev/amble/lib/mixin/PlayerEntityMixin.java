package dev.amble.lib.mixin;

import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.skin.PlayerSkinTexturable;
import org.spongepowered.asm.mixin.Mixin;

import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_7094;

@Mixin(class_1657.class)
public abstract class PlayerEntityMixin extends class_1309 implements AnimatedEntity, PlayerSkinTexturable {
	protected PlayerEntityMixin(class_1299<? extends class_1309> entityType, class_1937 world) {
		super(entityType, world);
	}

	private class_7094 amblekit$animationState = new class_7094();

	@Override
	public class_7094 getAnimationState() {
		return amblekit$animationState;
	}

	@Override
	public UUID method_5667() {
		return super.method_5667();
	}
}
