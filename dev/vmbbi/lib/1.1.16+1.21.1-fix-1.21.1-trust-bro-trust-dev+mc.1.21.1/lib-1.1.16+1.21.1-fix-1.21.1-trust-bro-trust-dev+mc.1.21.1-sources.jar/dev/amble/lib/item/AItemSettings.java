package dev.amble.lib.item;

import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1814;
import net.minecraft.class_4174;
import net.minecraft.class_5321;
import net.minecraft.class_7696;
import net.minecraft.class_7923;

public class AItemSettings extends class_1792.class_1793 {

    private class_1761 group;

    public AItemSettings group(class_1761 group) {
        this.group = group;
        return this;
    }
    public AItemSettings group(class_5321<class_1761> group) {
        this.group = class_7923.field_44687.method_29107(group);
        return this;
    }

    // Fabric-specific helpers (equipment slot / custom damage) are not available in vanilla Item.Settings.
    // Provide no-op-compatible stubs so callers still compile.
    public AItemSettings equipmentSlot(Object equipmentSlotProvider) {
        return this;
    }

    public AItemSettings customDamage(Object handler) {
        return this;
    }

    @Override
    public AItemSettings method_19265(class_4174 foodComponent) {
        return (AItemSettings) super.method_19265(foodComponent);
    }

    @Override
    public AItemSettings method_7889(int maxCount) {
        return (AItemSettings) super.method_7889(maxCount);
    }

    public AItemSettings maxDamageIfAbsent(int maxDamage) {
        // maxDamageIfAbsent was removed from Item.Settings; preserve compatibility by returning this.
        return this;
    }

    @Override
    public AItemSettings method_7895(int maxDamage) {
        return (AItemSettings) super.method_7895(maxDamage);
    }

    @Override
    public AItemSettings method_7896(class_1792 recipeRemainder) {
        return (AItemSettings) super.method_7896(recipeRemainder);
    }

    @Override
    public AItemSettings method_7894(class_1814 rarity) {
        return (AItemSettings) super.method_7894(rarity);
    }

    @Override
    public AItemSettings method_24359() {
        return (AItemSettings) super.method_24359();
    }

    @Override
    public AItemSettings method_45434(class_7696... features) {
        return (AItemSettings) super.method_45434(features);
    }

    public class_1761 group() {
        return group;
    }
}
