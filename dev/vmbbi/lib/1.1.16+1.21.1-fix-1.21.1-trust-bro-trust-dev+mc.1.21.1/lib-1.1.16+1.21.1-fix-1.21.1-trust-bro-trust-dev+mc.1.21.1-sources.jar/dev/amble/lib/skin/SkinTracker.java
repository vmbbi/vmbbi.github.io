package dev.amble.lib.skin;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.amble.lib.AmbleKit;
import dev.amble.lib.util.ServerLifecycleHooks;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public class SkinTracker extends HashMap<UUID, SkinData> {
	private static SkinTracker INSTANCE;

	public static SkinTracker getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new SkinTracker();
		}
		return INSTANCE;
	}

	public static void init() {
		INSTANCE = new SkinTracker();

		PayloadTypeRegistry.playS2C().register(SkinSyncPayload.ID, SkinSyncPayload.CODEC);

		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
			getInstance().sync(handler.method_32311());
		});

		ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
			getInstance().write(server);
		});

		ServerLifecycleEvents.SERVER_STARTED.register(SkinTracker::read);

		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			initClient();
		}
	}

	@Environment(EnvType.CLIENT)
	private static void initClient() {
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
			getInstance().clear();
		});

		ClientPlayNetworking.registerGlobalReceiver(SkinSyncPayload.ID, (payload, context) -> {
			context.client().execute(() -> getInstance().receive(payload));
		});
	}

	@Nullable
	public SkinData putSynced(UUID id, SkinData data) {
		SkinData previous = this.put(id, data);
		sync(new SkinSyncPayload(Map.of(id, data)));
		return previous;
	}

	@Nullable
	public SkinData removeSynced(UUID id) {
		SkinData previous = this.remove(id);
		sync(new SkinSyncPayload(Map.of(id, SkinData.clear())));
		return previous;
	}

	public Optional<SkinData> getOptional(UUID id) {
		return Optional.ofNullable(this.get(id));
	}

	private void sync(SkinSyncPayload payload) {
		if (ServerLifecycleHooks.get() == null) return;
		ServerLifecycleHooks.get().method_3760().method_14571().forEach((p) -> this.sync(payload, p));
	}

	private void sync(SkinSyncPayload payload, class_3222 player) {
		ServerPlayNetworking.send(player, payload);
	}

	private void receive(SkinSyncPayload payload) {
		payload.skins().forEach(this::put);
	}

	public void sync() {
		sync(new SkinSyncPayload(this));
	}

	public void sync(class_3222 target) {
		sync(new SkinSyncPayload(this), target);
	}

	private static Path getSavePath(MinecraftServer server) {
		return server.method_27050(class_5218.field_24188).resolve("amblekit").resolve("skins.json");
	}

	private void write(MinecraftServer server) {
		try {
			Path savePath = getSavePath(server);
			if (!Files.exists(savePath)) {
				Files.createDirectories(savePath.getParent());
			}

			Files.writeString(savePath, AmbleKit.GSON.toJson(this, SkinTracker.class));
		} catch (Exception e) {
			AmbleKit.LOGGER.error("Failed to write skins.json", e);
		}
	}

	private static void read(MinecraftServer server) {
		if (!(Files.exists(getSavePath(server)))) return;

		try {
			String raw = Files.readString(getSavePath(server));
			JsonObject object = JsonParser.parseString(raw).getAsJsonObject();
			INSTANCE = AmbleKit.GSON.fromJson(object, SkinTracker.class);
			INSTANCE.sync();
		} catch (Exception e) {
			AmbleKit.LOGGER.error("Failed to read skins.json", e);
		}
	}
}