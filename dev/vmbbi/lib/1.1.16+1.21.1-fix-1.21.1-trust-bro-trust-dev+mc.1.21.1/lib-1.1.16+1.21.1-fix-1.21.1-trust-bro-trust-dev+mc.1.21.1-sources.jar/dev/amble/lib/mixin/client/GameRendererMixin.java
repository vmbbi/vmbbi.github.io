package dev.amble.lib.mixin.client;

import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.client.bedrock.BedrockAnimation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Optional;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_757;
import net.minecraft.class_9779;

@Mixin(class_757.class)
public class GameRendererMixin {
	@Inject(method = "render", at = @At("HEAD"))
	private void amble$renderGame(class_9779 tickCounter, boolean tick, CallbackInfo ci) {
		class_746 player = class_310.method_1551().field_1724;

		if (player != null) {
			BedrockAnimation anim = BedrockAnimation.getFor((AnimatedEntity) player);
			Optional<Boolean> wasHudHidden = BedrockAnimation.WAS_HUD_HIDDEN;

			if (anim != null) {
				if (wasHudHidden.isEmpty()) { // start
					wasHudHidden = Optional.of(class_310.method_1551().field_1690.field_1842);

					if (anim.metadata.hideHud()) {
						class_310.method_1551().field_1690.field_1842 = true;
						BedrockAnimation.WAS_HUD_HIDDEN = wasHudHidden;
					}
				}
			} else {
				if (wasHudHidden.isPresent()) { // end
					class_310.method_1551().field_1690.field_1842 = wasHudHidden.get();
					wasHudHidden = Optional.empty();
					BedrockAnimation.WAS_HUD_HIDDEN = wasHudHidden;
				}
			}
		}
	}
}