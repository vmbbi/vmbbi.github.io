package dev.amble.lib.block;

import dev.amble.lib.block.behavior.api.BlockBehaviorLike;
import net.minecraft.class_1750;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3737;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;

@ApiStatus.Experimental
@SuppressWarnings("deprecation")
public class AWaterloggableBlock extends ABlock implements class_3737 {

    public static final class_2746 WATERLOGGED = class_2741.field_12508;

    public AWaterloggableBlock(ABlockSettings settings, BlockBehaviorLike... behaviors) {
        super(settings, behaviors);
    }

    @Override
    protected class_2680 createDefaultState() {
        return super.createDefaultState().method_11657(WATERLOGGED, false);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        class_3610 fluidState = ctx.method_8045().method_8316(ctx.method_8037());
        class_2680 state = this.method_9564().method_11657(WATERLOGGED, fluidState.method_15772() == class_3612.field_15910);

        return super.getPlacementState(state, ctx);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(WATERLOGGED);
    }

    @Override
    public class_3610 method_9545(class_2680 state) {
        return state.method_11654(WATERLOGGED) ? class_3612.field_15910.method_15729(false) : super.method_9545(state);
    }

    @Override
    public class_2680 method_9559(class_2680 state, class_2350 direction, class_2680 neighborState, class_1936 world, class_2338 pos, class_2338 neighborPos) {
        if (state.method_11654(WATERLOGGED)) world.method_39281(pos, class_3612.field_15910, class_3612.field_15910.method_15789(world));
        return super.method_9559(state, direction, neighborState, world, pos, neighborPos);
    }
}
