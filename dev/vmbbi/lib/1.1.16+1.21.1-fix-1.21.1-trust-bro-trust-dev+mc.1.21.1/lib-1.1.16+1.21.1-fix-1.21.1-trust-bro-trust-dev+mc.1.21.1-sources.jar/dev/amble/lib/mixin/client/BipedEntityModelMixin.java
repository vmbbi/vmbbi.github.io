package dev.amble.lib.mixin.client;

import dev.amble.lib.animation.AnimatedEntity;
import dev.amble.lib.animation.client.AnimatedEntityModel;
import dev.amble.lib.client.bedrock.BedrockAnimation;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.function.Function;
import net.minecraft.class_1309;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_572;
import net.minecraft.class_630;

@Mixin(class_572.class)
public class BipedEntityModelMixin<T extends class_1309> implements AnimatedEntityModel {
	@Unique
	class_630 root;

	@Shadow
	@Final
	public class_630 head;

	@Inject(method="setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("HEAD"))
	private void animation$setAnglePre(T livingEntity, float f, float g, float h, float i, float j, CallbackInfo ci) {
		if (!(livingEntity instanceof AnimatedEntity player)) return;

		this.applyAnimationPre(player, h);
	}

	@Inject(method="setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/model/ModelPart;copyTransform(Lnet/minecraft/client/model/ModelPart;)V"))
	private void animation$setAngle(T livingEntity, float f, float g, float h, float i, float j, CallbackInfo ci) {
		if (!(livingEntity instanceof AnimatedEntity player)) return;

		this.applyAnimation(player, h);

		if (!BedrockAnimation.IS_RENDERING_PLAYER || livingEntity != class_310.method_1551().field_1719) {
			return;
		}

		if (BedrockAnimation.IS_RENDERING_HEAD != null) {
			head.field_3665 = BedrockAnimation.IS_RENDERING_HEAD;
		}
	}

	@Inject(method = "<init>(Lnet/minecraft/client/model/ModelPart;Ljava/util/function/Function;)V", at = @At("TAIL"))
	public void animation$init(class_630 root, Function<class_2960, class_1921> renderLayerFactory, CallbackInfo ci) {
		this.root = root;
	}

	@Override
	public class_630 getPart() {
		return this.root;
	}
}
