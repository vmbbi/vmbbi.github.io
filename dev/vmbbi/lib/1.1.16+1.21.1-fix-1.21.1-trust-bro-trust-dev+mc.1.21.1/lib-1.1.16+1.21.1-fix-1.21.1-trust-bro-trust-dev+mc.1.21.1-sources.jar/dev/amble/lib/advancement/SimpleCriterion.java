package dev.amble.lib.advancement;

import dev.amble.lib.AmbleKit;
import net.minecraft.class_174;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_4558;
import net.minecraft.class_5258;
import com.mojang.serialization.Codec;
import org.jetbrains.annotations.ApiStatus;

public class SimpleCriterion extends class_4558<SimpleCriterion.Conditions> {
    protected final class_2960 id;

    protected SimpleCriterion(class_2960 id) {
        this.id = id;
    }


    @Override
    public Codec<SimpleCriterion.Conditions> method_54937() {
        return SimpleCriterion.Conditions.CODEC;
    }

    
    public class_2960 getId() {
        return this.id;
    }

    public void trigger(class_3222 player) {
        this.method_22510(player, SimpleCriterion.Conditions::requirementsMet);
    }

    /**
     * @return a newly created conditions object
     */
    public Conditions conditions() {
        return new Conditions();
    }

    public SimpleCriterion register() {
        AmbleKit.LOGGER.info("Registering criterion: {}", this.id);

        class_174.method_767(this.id.toString(), this);
        return this;
    }

    public static SimpleCriterion create(class_2960 id) {
        return new SimpleCriterion(id);
    }

    @ApiStatus.Internal
    public static SimpleCriterion create(String name) {
        return new SimpleCriterion(AmbleKit.id(name));
    }

    public static class Conditions implements class_4558.class_8788 {
        public static final Codec<Conditions> CODEC = Codec.unit(new Conditions());

        public Conditions() {
        }

        public java.util.Optional<class_5258> comp_2029() {
            return java.util.Optional.empty();
        }

        boolean requirementsMet() {
            return true;
        }
    }
}
