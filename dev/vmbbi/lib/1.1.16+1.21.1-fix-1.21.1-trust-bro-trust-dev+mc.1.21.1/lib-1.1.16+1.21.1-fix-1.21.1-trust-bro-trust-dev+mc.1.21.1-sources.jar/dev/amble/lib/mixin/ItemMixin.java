package dev.amble.lib.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import dev.amble.lib.item.AItem;
import dev.amble.lib.item.AItemSettings;
import net.minecraft.class_1761;
import net.minecraft.class_1792;

@Mixin(class_1792.class)
public class ItemMixin implements AItem {

    @Unique
    private class_1761 amble$group;

    @Inject(method = "<init>", at = @At("TAIL"))
    public void init(class_1792.class_1793 settings, CallbackInfo ci) {
        if (settings instanceof AItemSettings ais)
            this.amble$group = ais.group();
    }

    @Override
    public class_1761 amble$group() {
        return this.amble$group;
    }
}
