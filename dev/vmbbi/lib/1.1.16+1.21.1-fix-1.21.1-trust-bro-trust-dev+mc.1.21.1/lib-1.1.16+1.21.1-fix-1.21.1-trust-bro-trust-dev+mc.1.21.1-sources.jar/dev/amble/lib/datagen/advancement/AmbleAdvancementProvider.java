package dev.amble.lib.datagen.advancement;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.class_161;
import net.minecraft.class_175;
import net.minecraft.class_1802;
import net.minecraft.class_189;
import net.minecraft.class_1935;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7225.class_7874;
import net.minecraft.class_8779;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

public class AmbleAdvancementProvider extends FabricAdvancementProvider {

    private final List<Builder> builders = new ArrayList<>();

    public AmbleAdvancementProvider(FabricDataOutput output, CompletableFuture<class_7874> lookup) {
        super(output, lookup);
    }

    public Builder create(class_2960 parentId, String name) {
        Builder result = new Builder(parentId, name);
        builders.add(result);
        return result;
    }

    public Builder create(String name) {
        return create((class_2960) null, name);
    }

    public Builder task(class_2960 parentId, String name) {
        return create(parentId, name);
    }

    public Builder task(String name) {
        return create(name);
    }

    public Builder challenge(class_2960 parentId, String name) {
        return create(parentId, name).frame(class_189.field_1250);
    }

    public Builder goal(class_2960 parentId, String name) {
        return create(parentId, name).frame(class_189.field_1249);
    }

    @Override
    public void generateAdvancement(class_7874 lookup, Consumer<class_8779> consumer) {
        for (Builder builder : builders) {
            consumer.accept(builder.build());
        }
    }

    public class Builder {

        private final class_161.class_162 builder;

        private class_1935 item = class_1802.field_8077;
        private boolean hidden = false;
        private class_189 frame = class_189.field_1254;
        private class_2960 background;
        private boolean announce = true;
        private boolean showToast = true;

        private final String name;

        public Builder(class_2960 parentId, String name) {
            if (parentId != null) this.builder = class_161.class_162.method_707().method_708(parentId);
            else this.builder = class_161.class_162.method_707();
            this.name = name;
        }

        public Builder condition(String name, class_175<?> conditions) {
            // Fabric's datagen Advancement.Builder expects AdvancementCriterion<?> for criteria
            this.builder.method_705(name, conditions);
            return this;
        }

        public Builder icon(class_1935 item) {
            this.item = item;
            return this;
        }

        public Builder hidden() {
            this.hidden = true;
            return this;
        }

        public Builder frame(class_189 frame) {
            this.frame = frame;
            return this;
        }

        public Builder background(class_2960 background) {
            this.background = background;
            return this;
        }

        public Builder background(String background) {
            return background(class_2960.method_60655(AmbleAdvancementProvider.this.output.getModId(), background));
        }

        public Builder silent() {
            this.announce = false;
            return this;
        }

        public Builder noToast() {
            this.showToast = false;
            return this;
        }

        public class_8779 build() {
            String modId = AmbleAdvancementProvider.this.output.getModId();

            return builder
                    .method_697(item,
                            class_2561.method_43471("achievement." + modId + ".title." + name),
                            class_2561.method_43471("achievement." + modId + ".description." + name),
                            background, frame, showToast, announce, hidden)
                    .method_694(advancement -> {}, modId + ":" + name);
        }
    }
}
