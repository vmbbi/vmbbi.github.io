package dev.amble.lib.datagen.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import net.minecraft.class_2248;
import net.minecraft.class_3481;
import net.minecraft.class_6862;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface ShovelMineable {
    Tool tool() default Tool.NONE;

    enum Tool {
        NONE(null),
        STONE(class_3481.field_33719),
        IRON(class_3481.field_33718),
        DIAMOND(class_3481.field_33717),;

        public final class_6862<class_2248> tag;

        Tool(class_6862<class_2248> tag) {
            this.tag = tag;
        }
    }
}
