package dev.amble.plushies;

import dev.amble.lib.AmbleKit;
import dev.amble.lib.container.impl.SoundContainer;
import net.minecraft.class_3414;

public class PlushieSounds implements SoundContainer {
    public static final class_3414 BOOP = class_3414.method_47908(AmbleKit.id("secret/boop"));
}
