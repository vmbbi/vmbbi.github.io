package dev.amble.plushies.client;

import dev.amble.lib.AmbleKit;
import dev.amble.lib.client.bedrock.BedrockEntityModel;
import dev.amble.lib.client.bedrock.BedrockModelReference;
import dev.amble.plushies.MarketablePlushieBlock;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_765;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class PlushieDynamicItemRenderer implements BuiltinItemRendererRegistry.DynamicItemRenderer {

    @Override
    public void render(class_1799 stack, class_811 mode, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        if (stack.method_7909() instanceof class_1747 blockItem && blockItem.method_7711() instanceof MarketablePlushieBlock plushieBlock) {
            BedrockEntityModel<?> model = plushieBlock.model == null ? plushieBlock.model = refreshModel(plushieBlock) : plushieBlock.model;

            matrices.method_22903();
            matrices.method_22904(0.5D, 0.0D, 0.5D);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(180F));

            model.method_2828(
                    matrices,
                    vertexConsumers.getBuffer(class_1921.method_23578(plushieBlock.getTexture())),
                    light,
                    overlay,
                    0xFFFFFFFF
            );

            class_2960 emission = plushieBlock.getEmissionTexture();
            if (emission != null) {
                model.method_2828(
                        matrices,
                        vertexConsumers.getBuffer(class_1921.method_28116(emission)),
                        class_765.field_32767,
                        overlay,
                        0xFFFFFFFF
                );
            }

            matrices.method_22909();
        }
    }

    protected BedrockEntityModel<?> refreshModel(MarketablePlushieBlock block) {
        BedrockModelReference ref = block.getModel();
        if (ref == null) {
            throw new IllegalStateException("Block " + block + " does not have a BedrockModelReference");
        }
        return new BedrockEntityModel<>(ref.get().orElseThrow(() ->
                new IllegalStateException("BedrockModel " + ref.id() + " not found for block " + block)));
    }
}
