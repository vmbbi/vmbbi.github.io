package dev.amble.plushies.client;

import dev.amble.lib.animation.client.BedrockBlockEntityRenderer;
import dev.amble.lib.client.bedrock.BedrockEntityModel;
import dev.amble.plushies.MarketablePlushieBlock;
import dev.amble.plushies.MarketablePlushieBlockEntity;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_7833;

public class MarketablePlushieRenderer<T extends MarketablePlushieBlockEntity> extends BedrockBlockEntityRenderer<T> {

    private static final float MAX_SCALE = 3.0f;
    private static final float NORMAL_SCALE = 1.5f;

    public MarketablePlushieRenderer(class_5614.class_5615 context) {
        super(context);
    }

    @Override
    public void render(T entity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        class_2680 state = entity.method_11010();
        class_2248 block = state.method_26204();

        if (!(block instanceof MarketablePlushieBlock plushieBlock)) return;

        BedrockEntityModel<?> model = plushieBlock.model == null ? plushieBlock.model = refreshModel(entity) : plushieBlock.model;

        class_2680 downState = entity.method_10997().method_8320(entity.method_11016().method_10074());
        class_2248 downBlock = downState.method_26204();
        if (downBlock instanceof MarketablePlushieBlock && downState.method_11654(MarketablePlushieBlock.STACKED))
            return;

        matrices.method_22903();
        matrices.method_22904(0.5D, 0.0D, 0.5D);
        matrices.method_22907(class_7833.field_40714.rotationDegrees(180F));
        matrices.method_22907(class_7833.field_40716.rotationDegrees(entity.getRenderYaw()));

        boolean stacked = state.method_11654(MarketablePlushieBlock.STACKED);
        float scale = stacked ? MAX_SCALE : NORMAL_SCALE;
        matrices.method_22905(scale, scale, scale);

        model.setAngles(entity, entity.getAge() + tickDelta);

        model.method_2828(
                matrices,
                vertexConsumers.getBuffer(class_1921.method_23578(getTexture(entity))),
                light,
                overlay,
                0xFFFFFFFF
        );

        class_2960 emission = entity.getEmissionTexture();
        if (emission != null) {
            model.method_2828(
                    matrices,
                    vertexConsumers.getBuffer(class_1921.method_28116(emission)),
                    class_765.field_32767,
                    overlay,
                    0xFFFFFFFF
            );
        }

        matrices.method_22909();
    }
}
