package dev.amble.plushies.client;

import dev.amble.plushies.PlushieBlockEntities;
import dev.amble.plushies.PlushieBlocks;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.minecraft.class_2248;
import net.minecraft.class_5616;

public class PlushiesClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        class_5616.method_32144(PlushieBlockEntities.MARKETABLE_PLUSHIE_BLOCK_ENTITY_TYPE, MarketablePlushieRenderer::new);

        for (class_2248 block : PlushieBlocks.getAllMarketablePlushies()) {
            BuiltinItemRendererRegistry.INSTANCE.register(block.method_8389(), new PlushieDynamicItemRenderer());
        }
    }
}
