package dev.amble.plushies;

import dev.amble.lib.animation.HasBedrockModel;
import dev.amble.lib.container.impl.BlockEntityContainer;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2591;

public class PlushieBlockEntities implements BlockEntityContainer {

    public static final class_2591<MarketablePlushieBlockEntity> MARKETABLE_PLUSHIE_BLOCK_ENTITY_TYPE =
            FabricBlockEntityTypeBuilder.create(MarketablePlushieBlockEntity::new,
                    PlushieBlocks.getAllMarketablePlushies()
            ).build();

    @HasBedrockModel
    public static final class_2591<GiftBoxBlockEntity> GIFT_BOX_BLOCK_ENTITY_TYPE =
            FabricBlockEntityTypeBuilder.create(GiftBoxBlockEntity::new,
                    PlushieBlocks.GIFT_BOX
            ).build();
}
