package dev.amble.plushies;

import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2758;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_7718;
import org.jetbrains.annotations.Nullable;

public class GiftBoxBlock extends class_2248 implements class_2343 {

    public static final int MAX_ROTATION_INDEX = class_7718.method_45478();
    private static final int MAX_ROTATIONS = MAX_ROTATION_INDEX + 1;
    public static final class_2758 ROTATION = class_2741.field_12532;
    protected static final class_265 SHAPE = class_2248.method_9541(4.0F, 0.0F, 4.0F, 12.0F, 10.0F, 12.0F);

    public GiftBoxBlock(class_2251 settings) {
        super(settings);
        this.method_9590(this.field_10647.method_11664()
                .method_11657(ROTATION, 0));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_265 method_9571(class_2680 state, class_1922 world, class_2338 pos) {
        return class_259.method_1073();
    }

    @Override
    public class_265 method_9549(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        class_2248[] blocks = PlushieBlocks.getAllMarketablePlushies();
        int randomBlock = world.method_8409().method_39332(0, blocks.length - 1);
        class_1799 stack = new class_1799(blocks[randomBlock]);
        class_1542 itemEntity = new class_1542(world, pos.method_10263(), pos.method_10264() + 0.3d, pos.method_10260(), stack);
        itemEntity.method_6982(40);
        world.method_8396(null, pos, class_3417.field_14983, class_3419.field_15245, 1f, 1f);
        world.method_8396(null, pos, PlushieSounds.BOOP, class_3419.field_15245, 0.4f, 1f);
        world.method_8649(itemEntity);
        world.method_22352(pos, false);
        return class_1269.field_5812;
    }

    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564()
                .method_11657(ROTATION, class_7718.method_45479(ctx.method_8044()));
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(ROTATION, rotation.method_10502(state.method_11654(ROTATION), MAX_ROTATIONS));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_11657(ROTATION, mirror.method_10344(state.method_11654(ROTATION), MAX_ROTATIONS));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ROTATION);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11456;
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GiftBoxBlockEntity(PlushieBlockEntities.GIFT_BOX_BLOCK_ENTITY_TYPE, pos, state);
    }
}
