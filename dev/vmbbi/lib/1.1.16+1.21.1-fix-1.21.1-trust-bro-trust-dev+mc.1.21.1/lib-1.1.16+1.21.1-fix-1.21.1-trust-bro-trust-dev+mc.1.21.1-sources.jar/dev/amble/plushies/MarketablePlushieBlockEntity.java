package dev.amble.plushies;

import dev.amble.lib.animation.AnimatedBlockEntity;
import dev.amble.lib.blockentity.ABlockEntity;
import dev.amble.lib.client.bedrock.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3419;
import net.minecraft.class_3965;
import net.minecraft.class_7094;
import org.jetbrains.annotations.Nullable;

public class MarketablePlushieBlockEntity extends ABlockEntity implements AnimatedBlockEntity {

    private static final BedrockAnimationReference ANIMATION_REFERENCE = new BedrockAnimationReference("squish", "squish");

    private final class_7094 animationState = new class_7094();

    private int age = 0;

    public MarketablePlushieBlockEntity(class_2591<?> type, class_2338 pos, class_2680 state) {
        super(type, pos, state);
    }

    public MarketablePlushieBlockEntity(class_2338 blockPos, class_2680 blockState) {
        this(PlushieBlockEntities.MARKETABLE_PLUSHIE_BLOCK_ENTITY_TYPE, blockPos, blockState);
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public class_7094 getAnimationState() {
        return animationState;
    }

    @Override
    public String getTexturePrefix() {
        class_2248 block = this.method_11010().method_26204();
        if (block instanceof MarketablePlushieBlock plushieBlock) {
            return plushieBlock.getTexturePrefix();
        }
        return "block";
    }

    @Override
    public @Nullable BedrockModelReference getModel() {
        class_2248 block = this.method_11010().method_26204();
        if (block instanceof MarketablePlushieBlock plushieBlock) {
            return plushieBlock.getModel();
        }
        return null;
    }

    @Override
    public void tick(class_1937 world, class_2338 pos, class_2680 state) {
        age++;
    }

    @Override
    public float getRenderYaw() {
        return this.method_11010().method_11654(MarketablePlushieBlock.ROTATION) * 22.5f;
    }


    public class_1269 onUse(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.method_8608()) return class_1269.field_5812;
        world.method_8396(null, pos, PlushieSounds.BOOP, class_3419.field_15245, 0.4f, world.method_8409().method_43056() ? 1.0f : 0.9f);
        this.playAnimation(ANIMATION_REFERENCE);
        return class_1269.field_5812;
    }
}
